unsigned int sockaddr_size(const void *x);

void *sockaddr_addr_offset(const void *x);
unsigned int sockaddr_addr_size(const void *x);

in_port_t *sockaddr_port_offset(const void *x);
